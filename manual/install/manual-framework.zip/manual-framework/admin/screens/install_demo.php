<?php
/**
 * @author     Manual
 * @copyright  (c) Copyright by Manual
 * @link       https://wpsmartapps.com/
 * @package    Manual
 * @since      2.9
 */
 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

?>
<div class="wrap about-wrap">
    <?php manual__admin_menu_tabs('demos'); ?>
    <?php if (!class_exists('OCDI_Plugin')) { ?>
    <p class="manual-warning"><?php printf( __( 'You need to install and activate the following plugins to use our import function: <br><a %1$s>One Click Demo Import</a>', 'manual-framework' ), 'href="admin.php?page=manual-admin-plugins"' ); ?>
    </strong>
    </p>
    <?php } ?>
</div>